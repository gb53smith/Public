// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using namespace binary_sensor;
using namespace light;
using namespace switch_;
using namespace text_sensor;
logger::Logger *logger_logger;
status_led::StatusLED *status_led_statusled;
wifi::WiFiComponent *wifi_wificomponent;
ota::OTAComponent *ota_otacomponent;
api::APIServer *api_apiserver;
api::UserServiceTrigger<> *api_userservicetrigger;
Automation<> *automation;
using namespace sensor;
gpio::GPIOBinarySensor *gpio_gpiobinarysensor;
binary_sensor::PressTrigger *binary_sensor_presstrigger;
Automation<> *automation_3;
binary::BinaryLightOutput *binary_binarylightoutput;
light::LightState *light1;
using namespace output;
gpio::GPIOBinaryOutput *output1;
wifi_signal::WiFiSignalSensor *wifi_signal_wifisignalsensor;
uptime::UptimeSensor *uptime_uptimesensor;
restart::RestartSwitch *restart_my_esp;
wifi_info::IPAddressWiFiInfo *wifi_info_ipaddresswifiinfo;
output::TurnOnAction<> *output_turnonaction;
DelayAction<> *delayaction;
output::TurnOffAction<> *output_turnoffaction;
DelayAction<> *delayaction_2;
output::TurnOnAction<> *output_turnonaction_2;
DelayAction<> *delayaction_3;
output::TurnOffAction<> *output_turnoffaction_2;
DelayAction<> *delayaction_4;
output::TurnOnAction<> *output_turnonaction_3;
DelayAction<> *delayaction_5;
output::TurnOffAction<> *output_turnoffaction_3;
DelayAction<> *delayaction_6;
light::LightIsOnCondition<> *light_lightisoncondition;
IfAction<> *ifaction;
output::TurnOnAction<> *output_turnonaction_4;
api::UserServiceTrigger<> *api_userservicetrigger_2;
Automation<> *automation_2;
switch_::ToggleAction<> *switch__toggleaction;
using namespace api;
light::ToggleAction<> *light_toggleaction;
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ===== DO NOT EDIT ANYTHING BELOW THIS LINE =====
  // ========== AUTO GENERATED CODE BEGIN ===========
  // async_tcp:
  // esphome:
  //   name: heinz
  //   platform: ESP8266
  //   board: esp01_1m
  //   arduino_version: platformio/espressif8266@2.6.2
  //   build_path: heinz
  //   platformio_options: {}
  //   esp8266_restore_from_flash: false
  //   board_flash_mode: dout
  //   includes: []
  //   libraries: []
  //   name_add_mac_suffix: false
  App.pre_setup("heinz", __DATE__ ", " __TIME__, false);
  // binary_sensor:
  // light:
  // switch:
  // text_sensor:
  // logger:
  //   id: logger_logger
  //   baud_rate: 115200
  //   tx_buffer_size: 512
  //   hardware_uart: UART0
  //   level: DEBUG
  //   logs: {}
  //   esp8266_store_log_strings_in_flash: true
  logger_logger = new logger::Logger(115200, 512, logger::UART_SELECTION_UART0);
  logger_logger->pre_setup();
  App.register_component(logger_logger);
  // status_led:
  //   pin:
  //     number: 13
  //     inverted: true
  //     mode: OUTPUT
  //   id: status_led_statusled
  status_led_statusled = new status_led::StatusLED(new GPIOPin(13, OUTPUT, true));
  App.register_component(status_led_statusled);
  status_led_statusled->pre_setup();
  // wifi:
  //   networks:
  //   - ssid: GreenMountain
  //     password: !secret 'wifi_password'
  //     id: wifi_wifiap
  //     priority: 0.0
  //   - ssid: GreenMountain
  //     password: !secret 'wifi_password'
  //     id: wifi_wifiap_2
  //     priority: 0.0
  //   id: wifi_wificomponent
  //   enable_mdns: true
  //   domain: .local
  //   reboot_timeout: 15min
  //   power_save_mode: NONE
  //   fast_connect: false
  //   output_power: 20.0
  //   use_address: heinz.local
  wifi_wificomponent = new wifi::WiFiComponent();
  wifi_wificomponent->set_use_address("heinz.local");
  wifi::WiFiAP wifi_wifiap = wifi::WiFiAP();
  wifi_wifiap.set_ssid("GreenMountain");
  wifi_wifiap.set_password("dS8Dtma12y2D");
  wifi_wifiap.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap);
  wifi::WiFiAP wifi_wifiap_2 = wifi::WiFiAP();
  wifi_wifiap_2.set_ssid("GreenMountain");
  wifi_wifiap_2.set_password("dS8Dtma12y2D");
  wifi_wifiap_2.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap_2);
  wifi_wificomponent->set_reboot_timeout(900000);
  wifi_wificomponent->set_power_save_mode(wifi::WIFI_POWER_SAVE_NONE);
  wifi_wificomponent->set_fast_connect(false);
  wifi_wificomponent->set_output_power(20.0f);
  App.register_component(wifi_wificomponent);
  // ota:
  //   id: ota_otacomponent
  //   safe_mode: true
  //   port: 8266
  //   password: ''
  //   reboot_timeout: 5min
  //   num_attempts: 10
  ota_otacomponent = new ota::OTAComponent();
  ota_otacomponent->set_port(8266);
  ota_otacomponent->set_auth_password("");
  App.register_component(ota_otacomponent);
  if (ota_otacomponent->should_enter_safe_mode(10, 300000)) return;
  // api:
  //   services:
  //   - service: flash
  //     then:
  //     - output.turn_on:
  //         id: output1
  //       type_id: output_turnonaction
  //     - delay: 150ms
  //       type_id: delayaction
  //     - output.turn_off:
  //         id: output1
  //       type_id: output_turnoffaction
  //     - delay: 150ms
  //       type_id: delayaction_2
  //     - output.turn_on:
  //         id: output1
  //       type_id: output_turnonaction_2
  //     - delay: 150ms
  //       type_id: delayaction_3
  //     - output.turn_off:
  //         id: output1
  //       type_id: output_turnoffaction_2
  //     - delay: 150ms
  //       type_id: delayaction_4
  //     - output.turn_on:
  //         id: output1
  //       type_id: output_turnonaction_3
  //     - delay: 150ms
  //       type_id: delayaction_5
  //     - output.turn_off:
  //         id: output1
  //       type_id: output_turnoffaction_3
  //     - delay: 150ms
  //       type_id: delayaction_6
  //     - if:
  //         condition:
  //           light.is_on:
  //             id: light1
  //           type_id: light_lightisoncondition
  //         then:
  //         - output.turn_on:
  //             id: output1
  //           type_id: output_turnonaction_4
  //       type_id: ifaction
  //     automation_id: automation
  //     trigger_id: api_userservicetrigger
  //     variables: {}
  //   - service: restart
  //     then:
  //     - switch.toggle:
  //         id: restart_my_esp
  //       type_id: switch__toggleaction
  //     automation_id: automation_2
  //     trigger_id: api_userservicetrigger_2
  //     variables: {}
  //   id: api_apiserver
  //   port: 6053
  //   password: ''
  //   reboot_timeout: 15min
  api_apiserver = new api::APIServer();
  App.register_component(api_apiserver);
  api_apiserver->set_port(6053);
  api_apiserver->set_password("");
  api_apiserver->set_reboot_timeout(900000);
  api_userservicetrigger = new api::UserServiceTrigger<>("flash", {});
  api_apiserver->register_user_service(api_userservicetrigger);
  automation = new Automation<>(api_userservicetrigger);
  // sensor:
  // substitutions:
  //   l_name: heinz
  //   u_name: Heinz
  // binary_sensor.gpio:
  //   platform: gpio
  //   pin:
  //     number: 13
  //     mode: INPUT_PULLUP
  //     inverted: true
  //   name: Heinz button
  //   on_press:
  //   - then:
  //     - light.toggle:
  //         id: light1
  //       type_id: light_toggleaction
  //     automation_id: automation_3
  //     trigger_id: binary_sensor_presstrigger
  //   id: gpio_gpiobinarysensor
  gpio_gpiobinarysensor = new gpio::GPIOBinarySensor();
  App.register_component(gpio_gpiobinarysensor);
  App.register_binary_sensor(gpio_gpiobinarysensor);
  gpio_gpiobinarysensor->set_name("Heinz button");
  binary_sensor_presstrigger = new binary_sensor::PressTrigger(gpio_gpiobinarysensor);
  automation_3 = new Automation<>(binary_sensor_presstrigger);
  // light.binary:
  //   platform: binary
  //   name: Heinz
  //   id: light1
  //   output: output1
  //   restore_mode: RESTORE_DEFAULT_OFF
  //   output_id: binary_binarylightoutput
  binary_binarylightoutput = new binary::BinaryLightOutput();
  light1 = new light::LightState("Heinz", binary_binarylightoutput);
  App.register_light(light1);
  App.register_component(light1);
  light1->set_restore_mode(light::LIGHT_RESTORE_DEFAULT_OFF);
  light1->add_effects({});
  // output:
  // output.gpio:
  //   platform: gpio
  //   pin:
  //     number: 12
  //     mode: OUTPUT
  //     inverted: false
  //   id: output1
  output1 = new gpio::GPIOBinaryOutput();
  App.register_component(output1);
  output1->set_pin(new GPIOPin(12, OUTPUT, false));
  // sensor.wifi_signal:
  //   platform: wifi_signal
  //   name: Heinz WiFi signal
  //   update_interval: 60s
  //   force_update: false
  //   unit_of_measurement: dBm
  //   device_class: signal_strength
  //   state_class: measurement
  //   id: wifi_signal_wifisignalsensor
  wifi_signal_wifisignalsensor = new wifi_signal::WiFiSignalSensor();
  wifi_signal_wifisignalsensor->set_update_interval(60000);
  App.register_component(wifi_signal_wifisignalsensor);
  App.register_sensor(wifi_signal_wifisignalsensor);
  wifi_signal_wifisignalsensor->set_name("Heinz WiFi signal");
  wifi_signal_wifisignalsensor->set_device_class("signal_strength");
  wifi_signal_wifisignalsensor->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  wifi_signal_wifisignalsensor->set_unit_of_measurement("dBm");
  wifi_signal_wifisignalsensor->set_force_update(false);
  // sensor.uptime:
  //   platform: uptime
  //   name: Heinz uptime
  //   force_update: false
  //   unit_of_measurement: s
  //   icon: mdi:timer-outline
  //   id: uptime_uptimesensor
  //   update_interval: 60s
  uptime_uptimesensor = new uptime::UptimeSensor();
  uptime_uptimesensor->set_update_interval(60000);
  App.register_component(uptime_uptimesensor);
  App.register_sensor(uptime_uptimesensor);
  uptime_uptimesensor->set_name("Heinz uptime");
  uptime_uptimesensor->set_unit_of_measurement("s");
  uptime_uptimesensor->set_icon("mdi:timer-outline");
  uptime_uptimesensor->set_force_update(false);
  // switch.restart:
  //   platform: restart
  //   id: restart_my_esp
  //   icon: mdi:restart
  //   name: restart_my_esp
  //   internal: true
  restart_my_esp = new restart::RestartSwitch();
  App.register_component(restart_my_esp);
  App.register_switch(restart_my_esp);
  restart_my_esp->set_name("restart_my_esp");
  restart_my_esp->set_internal(true);
  restart_my_esp->set_icon("mdi:restart");
  // text_sensor.wifi_info:
  //   platform: wifi_info
  //   ip_address:
  //     name: Heinz IP
  //     id: wifi_info_ipaddresswifiinfo
  wifi_info_ipaddresswifiinfo = new wifi_info::IPAddressWiFiInfo();
  App.register_component(wifi_info_ipaddresswifiinfo);
  App.register_text_sensor(wifi_info_ipaddresswifiinfo);
  wifi_info_ipaddresswifiinfo->set_name("Heinz IP");
  output_turnonaction = new output::TurnOnAction<>(output1);
  delayaction = new DelayAction<>();
  App.register_component(delayaction);
  delayaction->set_delay(150);
  output_turnoffaction = new output::TurnOffAction<>(output1);
  delayaction_2 = new DelayAction<>();
  App.register_component(delayaction_2);
  delayaction_2->set_delay(150);
  output_turnonaction_2 = new output::TurnOnAction<>(output1);
  delayaction_3 = new DelayAction<>();
  App.register_component(delayaction_3);
  delayaction_3->set_delay(150);
  output_turnoffaction_2 = new output::TurnOffAction<>(output1);
  delayaction_4 = new DelayAction<>();
  App.register_component(delayaction_4);
  delayaction_4->set_delay(150);
  output_turnonaction_3 = new output::TurnOnAction<>(output1);
  delayaction_5 = new DelayAction<>();
  App.register_component(delayaction_5);
  delayaction_5->set_delay(150);
  output_turnoffaction_3 = new output::TurnOffAction<>(output1);
  delayaction_6 = new DelayAction<>();
  App.register_component(delayaction_6);
  delayaction_6->set_delay(150);
  light_lightisoncondition = new light::LightIsOnCondition<>(light1);
  ifaction = new IfAction<>(light_lightisoncondition);
  output_turnonaction_4 = new output::TurnOnAction<>(output1);
  ifaction->add_then({output_turnonaction_4});
  automation->add_actions({output_turnonaction, delayaction, output_turnoffaction, delayaction_2, output_turnonaction_2, delayaction_3, output_turnoffaction_2, delayaction_4, output_turnonaction_3, delayaction_5, output_turnoffaction_3, delayaction_6, ifaction});
  api_userservicetrigger_2 = new api::UserServiceTrigger<>("restart", {});
  api_apiserver->register_user_service(api_userservicetrigger_2);
  automation_2 = new Automation<>(api_userservicetrigger_2);
  switch__toggleaction = new switch_::ToggleAction<>(restart_my_esp);
  automation_2->add_actions({switch__toggleaction});
  light_toggleaction = new light::ToggleAction<>(light1);
  automation_3->add_actions({light_toggleaction});
  gpio_gpiobinarysensor->set_pin(new GPIOPin(13, INPUT_PULLUP, true));
  binary_binarylightoutput->set_output(output1);
  // =========== AUTO GENERATED CODE END ============
  // ========= YOU CAN EDIT AFTER THIS LINE =========
  App.setup();
}

void loop() {
  App.loop();
}

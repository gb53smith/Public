#include "automation.h"
#include "esphome/core/log.h"

namespace esphome {
namespace output {

static const char *TAG = "output.automation";

}  // namespace output
}  // namespace esphome

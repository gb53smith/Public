#include "automation.h"
#include "esphome/core/log.h"

namespace esphome {
namespace sensor {

static const char *TAG = "sensor.automation";

}  // namespace sensor
}  // namespace esphome

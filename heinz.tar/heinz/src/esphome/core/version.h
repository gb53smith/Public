#pragma once
#define ESPHOME_VERSION "1.19.1"

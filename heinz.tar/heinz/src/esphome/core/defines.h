#pragma once
#define ESPHOME_BOARD "esp01_1m"
#define USE_API
#define USE_BINARY_SENSOR
#define USE_LIGHT
#define USE_LOGGER
#define USE_MDNS
#define USE_SENSOR
#define USE_STATUS_LED
#define USE_SWITCH
#define USE_TEXT_SENSOR
#define USE_WIFI
